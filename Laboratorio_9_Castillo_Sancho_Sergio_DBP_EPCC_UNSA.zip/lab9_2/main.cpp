#include <iostream>
#include "Funcion.h"
using namespace std;

template<class T, typename T1, typename T2>
T operacionesBasicas(T1 num1, T2 num2);

int main(){
  int a; float b;
  //cout<<" SEGUNDO NUMERO: "; cin>>b;
  cout<<" Operaciones basicas con enteros 3 y 5\n";
  operacionesBasicas<int,int >(3,5);
  cout<<" Operaciones basicas con floats 4.2 y 0.6\n";

  operacionesBasicas<float,float>(4.2,0.6);

  return 0;
}

