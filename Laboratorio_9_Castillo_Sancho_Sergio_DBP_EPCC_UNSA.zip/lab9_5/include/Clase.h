#include<iostream>

using namespace std;
template <class P>
void ascendente(P lista[5]) {
P a;
for (int indice = 0; indice<= 4; indice++) {
    for (int indicex = indice; indicex <= 4; indicex += 1) {
        if (lista[indice] > lista[indicex]) {
        a = lista[indice];
        lista[indice] = lista[indicex];
        lista[indicex] = a;
        }
    }
}
for (int indice= 0; indice< 5; indice++) {
    cout << lista[indice] << " ";
    }
}
template <class P>
void descendente(P lista[5]) {
    P a;
    for (int indice= 0; indice<= 4; indice++) {
        for (int indicex = indice; indicex <= 4; indicex += 1) {
            if (lista[indice] > lista[indicex]) {
                a = lista[indice];
                lista[indice] = lista[indicex];
                lista[indicex] = a;
        }
    }
}
P lista2[5];
int aux = 0;
for (int indice = 4; indice>= 0; indice--) {
lista2[aux]= lista[indice];
aux++;
}
for (int indice = 0; indice< 5; indice++) {
cout << lista2[indice] << " ";
}
}
