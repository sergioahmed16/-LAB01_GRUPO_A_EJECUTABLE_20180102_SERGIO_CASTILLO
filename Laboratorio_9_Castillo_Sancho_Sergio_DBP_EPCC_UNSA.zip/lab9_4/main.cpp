#include<iostream>
using namespace std;

template <typename T>
//FUNCION MAXIMO
T maximo(T *arreglo, int dimension)
{
	T mayor = arreglo[0];
	for(int i = 1; i < dimension; i++)
	{
		if(arreglo[i] > mayor)
		{
			mayor = arreglo[i];
		}
	}
	return mayor;
}
//FUNCION MINIMO
template <typename T>
T minimo(T *arreglo, int dimension)
{
	T menor = arreglo[0];
	for(int i = 1; i < dimension; i++)
	{
		if(arreglo[i] < menor)
		{
			menor = arreglo[i];
		}
	}
	return menor;
}

template <typename T>
void imprimirArreglo(T *arreglo, int dimension)
{
	for(int i = 0; i != dimension; i++)
	{
		cout << arreglo[i] << " ";
	}
	cout << endl;
}

int main()
{
	cout<<"---Se muestran los arreglos, sus minimos y sus maximos:---\n";
	int ArrayEntero[5] = {10,7,2,8,6};
	float ArrayFloat[5] = {10.1,8.4,3.6,4.4,11.2};
	cout << "Enteros: ";
	//ENTEROS
	imprimirArreglo<int>(ArrayEntero, 5);
	cout << "\nmaximo entero: " << maximo<int>(ArrayEntero,5) << endl;
	cout << "minimo entero: " << minimo<int>(ArrayEntero,5) << endl;
	cout << "\nFlotantes: ";
	//FLOTANTES
	imprimirArreglo<float>(ArrayFloat, 5);
	cout << "\nmaximo flotante: " << maximo<float>(ArrayFloat,5) << endl;
	cout << "minimo flotante: " << minimo<float>(ArrayFloat,5) << endl;
	return 0;
}
