#ifndef COORDENADA_H
#define COORDENADA_H
// coordenada.h
template <class T>
class Coordenada {
private:
T x;
T y;
T z;
public:
Coordenada(T x = 0, T y = 0, T z=0);
T getX(){
    return x;
    }
T getY(){
    return y;
}-
T getZ(){
    return z;
    }
T getmax(){
    T maximo=x;
     if (y>maximo){
        maximo=y;
    }
    if (z>maximo){
        maximo=z;
    }
    T minimo=x;
    if (y<x){
        minimo=y;
    }
     if (z<minimo){
        minimo=z;
    }
    return maximo;
}
T getmin(){
    T minimo=x;
    if (y<x){
        minimo=y;
    }
     if (z<minimo){
        minimo=z;
    }
    return minimo;
}
};

template <class T>
Coordenada<T>::Coordenada(T x, T y, T z) {
this->x = x;
this->y = y;
this->z = z;

}

#endif // COORDENADA_H
