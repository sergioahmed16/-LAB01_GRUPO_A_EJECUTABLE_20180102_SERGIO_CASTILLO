#include <iostream>
#include "Coordenada.h"
using namespace std;
int main()
{
Coordenada <int> coord1(5, 2,10); // Enteros
cout<<"Sergio Castillo Sancho Lab9_1"<<endl;

cout<<"Se tienen los numeros:"<<coord1.getX()
<<", "<<coord1.getY()<<", "<<coord1.getZ()<<endl;

cout << "El Maximo  es: " << coord1.getmax() << endl;

cout << "El Minimo es: " << coord1.getmin() << endl;

system("pause");
return 0;
}
