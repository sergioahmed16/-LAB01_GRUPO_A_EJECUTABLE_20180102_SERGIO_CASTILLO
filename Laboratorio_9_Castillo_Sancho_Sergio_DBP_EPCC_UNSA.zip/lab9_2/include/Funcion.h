#ifndef FUNCION_H
#define FUNCION_H
#include <iostream>
using namespace std;
template<class T, typename T1, typename T2>
T operacionesBasicas(T1 num1, T2 num2){
  int op;
  do{
    cout<<"\nOPERACIONES BASICAS"<<endl;
    cout<<"[1] SUMA\n[2] RESTA\n[3] MULTIPLICACION\n[4] DIVISION"<<endl;
    cout<<"Ingrese una opcion => "; cin>>op;
    switch (op){
      case 1: cout<<"EL RESULTADO ES: "<<num1+num2<<endl;

      return num1+num2;

      break;
      case 2: cout<<"EL RESULTADO ES: "<<num1-num2<<endl;
      return num1-num2;
      break;
      case 3: cout<<"EL RESULTADO ES: "<<num1*num2<<endl;
      return num1*num2;
      break;
      case 4: cout<<"EL RESULTADO ES: "<<num1/num2<<endl;
      return num1/num2;
      break;
    }

    cin.get();

  }while( op>0 && op<=4);

}

#endif // FUNCION_H
