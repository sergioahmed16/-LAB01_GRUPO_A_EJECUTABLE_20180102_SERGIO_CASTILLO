#ifndef CLASE_H
#define CLASE_H
#include <iostream>
#include <cstring>
#include <string>


using namespace std;

template <class T, class P>
class CorreoUnsa{
private:
    T* nombre;
    P apellido;
public:
    CorreoUnsa(T *nombre, P apellido);
    void imprimir();
};

template <class T, class P>
CorreoUnsa<T, P>::CorreoUnsa(T *nombre, P apellido){
    this->nombre = nombre;
    this->apellido = apellido;
}
template <class T, class P>
void CorreoUnsa<T, P >::imprimir(){
     cout<<*(nombre);
    cout << apellido << "@unsa.edu.pe" << endl;
}

#endif // CLASE_H
