#include "clase.h"
#include<iostream>
int main() {
int ArrayEnteros[5] = { 5,7,2,8,6};
float ArrayFloats[5] = { 10.1, 8.4, 3.6, 4.4, 11.2 };
cout<<"Plantillas y arreglos:\n";
cout << endl<< "El arreglo entero ascendente: " << endl;
ascendente<int>(ArrayEnteros);
cout << endl<< "El arreglo entero descendente: " << endl;

descendente<int>(ArrayEnteros);
cout << endl;
cout << endl<< "El arreglo float ascendente: " << endl;
ascendente<float>(ArrayFloats);
cout << endl<< "El arreglo float descendente: " << endl;
descendente<float>(ArrayFloats);
return 0;
}
